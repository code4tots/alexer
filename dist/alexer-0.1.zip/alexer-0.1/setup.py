from distutils.core import setup

setup(
    name = 'alexer',
    packages = ['alexer'],
    version = '0.1',
    description='dead simple lexer',
    author = 'Kyumin Kim',
    author_email = 'math4tots@gmail.com',
    url = 'https://github.com/math4tots/alexer',
    download_url = 'https://github.com/math4tots/alexer/0.1',
    keywords = ['lexer'],
    classifiers = [])
